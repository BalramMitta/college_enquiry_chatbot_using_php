<?php
class Bot{

function addWords($word,$cat){
global $conn;
$word=strtolower($word);
$sql="insert into dictionary(`word`,`cat`) values('$word','$cat')";
$conn->query($sql);
}
function addSimilarWords($word,$similar){
	$word=strtolower($word);
	$similar=strtolower($similar);
global $conn;
$sql="insert into similar_words(`word`,`similar`) values('$word','$similar')";
$conn->query($sql);
}
function addPeople($name_str,$desc){
global $conn;
	$name_str=strtolower($name_str);
$sql="insert into people(`name`,`desc`) values('$name_str','$desc')";
$conn->query($sql);
}
function addQueries($q,$r){
global $conn;
	$q=strtolower($q);
$sql="insert into responses(`title`,`response`) values('$q','$r')";
$conn->query($sql);
}
function getQid($q){
global $conn;
	$q=strtolower($q);
$sql="select id from responses where title='$q'";
$res=$conn->query($sql);
$row=$res->fetch_assoc();
return $row["id"];
}
function addSimQueries($id,$q){
global $conn;
	$q=strtolower($q);
$sql="insert into queries(`id`,`query`) values('$id','$q')";
$conn->query($sql);
}
function numNewPeople(){
global $conn;
$sql="select count(*) as n from temp_people";
$result=$conn->query($sql);
$row = $result->fetch_assoc();
return $row["n"];
}
function numNewQueries(){
global $conn;
$sql="select count(*) as n from temp_queries";
$result=$conn->query($sql);
$row = $result->fetch_assoc();
return $row["n"];
}
function numNewWords(){
global $conn;
$sql="select * from temp_dictionary";
$result=$conn->query($sql);
return $result->num_rows;
}

}


?>
