<?php 
include('php-nlp-tools/autoloader.php');
use \NlpTools\Tokenizers\RegexTokenizer;
use \NlpTools\Similarity\Simhash;
use \NlpTools\Similarity\CosineSimilarity;
class Common{
	function getString($qstr){
$new_str="";
foreach($qstr as $w){
$new_str=$new_str." ".$w;
}
return trim($new_str);
}
	

function getResponse($t_query,$arr){
global $conn;
	$sql="select * from responses where id in (select id from queries where query='$t_query')";
$result=$conn->query($sql);
if($result->num_rows>0){
$row=$result->fetch_assoc();
if($row["action"]=="display")
return $row["response"];
else{
	$strq=implode(" ",$arr);
	$sql="select * from people where name='$strq'";
	$res=$conn->query($sql);
	if($res->num_rows>0){
		$row=$res->fetch_assoc();
		return $row["desc"];
	}
	else
		return "Sorry, We cannot find him/her.";
}
}else{
return 0;
}
}
	
function changeSimilar($arr){
$n=sizeof($arr);
global $conn;
$unknowns=array();
for($i=0;$i<$n;$i++){
$sql="select * from similar_words where similar='$arr[$i]'";
$result=$conn->query($sql);
if($result->num_rows>0){
$row=$result->fetch_assoc();
$arr[$i]=$row["word"];
}
else{
$unknowns[]=$arr[$i];	
}
}
return array($arr,$unknowns);
}
function modifyString($qstr){
$new_str="";
global $conn;
foreach($qstr as $w){
$sql="select * from dictionary where word='$w'";
$result=$conn->query($sql);
if($result->num_rows>0){
$new_str=$new_str." ".$w;
}
else{
$new_str=$new_str." *";
}
}
while(strpos($new_str,"* *")){
$new_str=str_replace("* *","*",$new_str);
}
return trim($new_str);

}

function advanceSearch($b,$arr){
	
global $conn;

$tok = new RegexTokenizer(array(
    array("/\s+/"," "),              // replace many spaces with a single space
    array("/'(m|ve|d|s)/", " '\$1"), // split I've, it's, we've, we'd, ...
    "/ /"                            // split on every space
));
$simhash = new Simhash(16); // 16 bits hash
$cos=new CosineSimilarity();
$set1=$tok->tokenize($b);
$sql="select * from queries";
$res=$conn->query($sql);
$row=$res->fetch_assoc();
$set2=$tok->tokenize($row["query"]);
$max1=$cos->similarity($set1,$set2);
$max2=$simhash->similarity($set1,$set2);
		$max_id=$row["id"];

while($row=$res->fetch_assoc()){
	
$set2=$tok->tokenize($row["query"]);
$temp_max2=$simhash->similarity($set1,$set2);
$temp_max1=$cos->similarity($set1,$set2);
	if(($temp_max1>$max1) || ($temp_max1==$max1 && $temp_max2>$max2)){
		$max2=$temp_max2;
		$max1=$temp_max1;
		$max_id=$row["id"];
		$max_q=$row["query"];
	}
}
if($max1>=0.33 && $max2 > 0.6){
	$sql1="select * from responses where id='$max_id'";
	$res1=$conn->query($sql1);
	$row1=$res1->fetch_assoc();
	if($row1["action"]=="display")
      $response=$row1["response"];
else{
	$strq=implode(" ",$arr);
	$sql="select * from people where name='$strq'";
	$res=$conn->query($sql);
	if($res->num_rows>0){
		$row=$res->fetch_assoc();
		$response=$row["desc"];
	}
	else
		$response="Sorry, We cannot find him/her.";
}
	return "<p><b><em>Did you mean:</em></b><em>$max_q?</em></p><p>".$response."</p>";
}
else
	return 0;
}





}
?>
