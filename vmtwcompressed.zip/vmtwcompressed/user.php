<?php
class User {
var $username;

function addWords($word){
global $conn;
$sql="insert into temp_dictionary(`word`) values('$word')";
$conn->query($sql);
}
function addPeople($name_str,$desc){
global $conn;
$sql="insert into temp_people(`name`,`desc`) values('$name_str','$desc')";
$conn->query($sql);
}
function addQueries($q,$r){
global $conn;
$sql="insert into temp_queries(`query`,`response`) values('$q','$r')";
$conn->query($sql);
}
function findStudent($name){
global $conn;
$sql="select * from students where fullname LIKE '%$name%'";
$result=$conn->query($sql);
if($result->num_rows >0){
$i=0;
while($row = $result->fetch_assoc()) {
$arr[$i]=array(
"name"=>$row["fullname"],
"id"=>$row["id"],
"gender"=>$row["gender"],
"branch"=>$row["branch"],
"year"=>$row["year"],
"desc"=>$row["desc"]
);
$i++;
}
return $arr;
}
else{
return 0;
}
}

function findPeople($name){
global $conn;
$sql="select * from people where name LIKE '%$name%'";
$result=$conn->query($sql);
if($result->num_rows >0){
$i=0;
while($row = $result->fetch_assoc()) {
$arr[$i]=array(
"name"=>$row["name"],
"desc"=>$row["desc"]
);
$i++;
}
return $arr;
}
else{
return 0;
}
}

}
