<?php

	include "connection.php";
if(isset($_GET["id"])){
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="mdl/material.min.css">
<script type="text/javascript" src="js/jquery-3.2.1.js"></script>
<script src="mdl/material.min.js"></script>
<script>
function adds(id){
	$.ajax({
		type:"POST",
		data:{
		id:id,
		q:$("#q").val()
		},
		url:"adds.php",
		success:function(data){
			location.reload();
		}
	});
}

</script>
<style>
	.mdl-layout__header{
	background-color: #229966;
}
.mdl-layout__drawer-button i{
	padding-top:10px;
}
	div.page-content{
		overflow:auto;
	}
	
div.mdl-layout__drawer{
  background:#999;
  border:none;
}
span.mdl-layout-title{
	font-size:2em;
font-family: 'David Libre', serif;
}
.side_title{
	color:#ffffff;
}
.mdl-layout__drawer .mdl-navigation .mdl-navigation__link {
	text-decoration:none;
font-family: 'David Libre', serif;
font-size:1.2em;
color:#ffffff;
}
.mdl-layout__drawer .mdl-navigation .mdl-navigation__link:hover{
	color:#000000;
	background:rgba(255,255,255,0.4);
	text-shadow: 1px 5px 15px black;
}
table{
	margin:auto;
	margin-top:50px;
	min-width:80%;
}
</style>
</head>
<body>
<!-- The drawer is always open in large screens. The header is always shown,
  even in small screens. -->

<div class="mdl-layout mdl-js-layout mdl-layout--fixed-drawer
            mdl-layout--fixed-header">
  <header class="mdl-layout__header">
    <div class="mdl-layout__header-row">
      <div class="mdl-layout-spacer"></div>
      <div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable
                  mdl-textfield--floating-label mdl-textfield--align-right">
        <label class="mdl-button mdl-js-button mdl-button--icon"
               for="fixed-header-drawer-exp">
          <i class="material-icons">search</i>
        </label>
        <div class="mdl-textfield__expandable-holder">
          <input class="mdl-textfield__input" type="text" name="sample"
                 id="fixed-header-drawer-exp">
        </div>
      </div>
    </div>
  </header>
  <div class="mdl-layout__drawer">
    <span class="mdl-layout-title">VMTW</span>
    <nav class="mdl-navigation">
      <a class="mdl-navigation__link" href="people.php">People</a>
      <a class="mdl-navigation__link" href="words.php">Words</a>
      <a class="mdl-navigation__link" href="queries.php">Unanswered</a> 
      <a class="mdl-navigation__link" href="queries_data.php">All queries</a> 
    </nav>
  </div>
  <main class="mdl-layout__content">
    <div class="page-content">
	<table class="mdl-data-table mdl-js-data-table mdl-shadow--2dp">
  <tbody>
  	<?php 
	$id=$_GET["id"];
	$i=1;
	$sql1="select * from responses where id=$id";
	$result1=$conn->query($sql1);
	$row1=$result1->fetch_assoc();
	$title=$row1["title"];
	$response=$row1["response"];
	?><tr>
      <th class="mdl-data-table__cell--non-numeric">Query title</th>
      <td><?php echo $title; ?></td>
    </tr><tr>
      <th class="mdl-data-table__cell--non-numeric">Response</th>
      <td><?php echo $response; ?></td>
    </tr>
	<tr>
      <th colspan=2 >Similar Queries</th>
    </tr>
		<?php
	$sql2="select * from queries where id=$id";
	$result2=$conn->query($sql2);
	if($result2->num_rows>0){
		$i=0;
		while($row2=$result2->fetch_assoc()){
			$i++;
			$query=$row2["query"];
			$did=$row2["indx"];
	?><tr>
	<td class="mdl-data-table__cell--non-numeric"><?php echo $i; ?> </td>
      <td><?php echo $query; ?></td>
    </tr>
		<?php }
	}
	?>
	<tr>
      <td> <div class="mdl-textfield mdl-js-textfield">
    <input class="mdl-textfield__input" type="text" name="q" id="q">
    <label class="mdl-textfield__label" for="q">New Similar</label>
    <span class="mdl-textfield__error">Enter only alphabets</span>
  </div></td>
      <td><a onclick="adds(<?php echo $id; ?>)" > Add </a> </td>
    </tr>
  </tbody>
</table>
	</div>
  </main>
</div>
</body>
</html>

<?php
}
?>