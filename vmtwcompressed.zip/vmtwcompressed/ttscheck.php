<?php
require_once('voicerss_tts.php');

$tts = new VoiceRSS;
$voice = $tts->speech([
    'key' => 'bf2d99d9f5674a3ba1e24da442ddc263',
    'hl' => 'en-us',
    'src' => $_POST["data"],
    'r' => '0',
    'c' => 'mp3',
    'f' => '44khz_16bit_stereo',
    'ssml' => 'false',
    'b64' => 'true'
]);

echo $voice['response'];

?>
