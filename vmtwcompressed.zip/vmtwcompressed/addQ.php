<?php
if(isset($_POST["id"])){
include "connection.php";
$id=$_POST["id"];
$q=$_POST["query"];
$r=$_POST["response"];
include "bot.php";
 $b=new Bot;
$b->addQueries($q,$r);
$i=$b->getQid($q);
$b->addSimQueries($i,$q);
}
?>