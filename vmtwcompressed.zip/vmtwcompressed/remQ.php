<?php
if(isset($_POST["id"])){
include "connection.php";
$id=$_POST["id"];
$sql="delete from temp_queries where id=$id";
$conn->query($sql);
}
?>