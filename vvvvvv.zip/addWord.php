<?php
if(isset($_POST["id"])){
include "connection.php";
$id=$_POST["id"];
$org=$_POST["org"];
$sim=$_POST["sim"];
include "bot.php";
 $b=new Bot;
 $sql="select * from  dictionary where word='$org'";
 $res=$conn->query($sql);
 if($res->num_rows>0){
	 $b->addSimilarWords($org,$sim);
 }
 else{
	 $b->addWords($org,"");
	 $b->addSimilarWords($org,$org);
	 $b->addSimilarWords($org,$sim);
 }
 


}
?>