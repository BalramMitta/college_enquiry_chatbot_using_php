<?php
if(isset($_POST["id"])){
include "connection.php";
$id=$_POST["id"];

$sql="delete from queries where indx=$id";
$conn->query($sql);
}
?>