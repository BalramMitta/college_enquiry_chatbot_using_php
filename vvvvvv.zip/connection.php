<?php
$servername = "50.62.209.113:3306";
$username = "vmtw211221";
$password = "vmtwpass211221";
$dbname = "vmtw";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);

}
?>