<?php 
if(isset($_POST["id"])){
include "connection.php";
$id=$_POST["id"];
$q=$_POST["q"];
include "bot.php";
 $b=new Bot;
$b->addSimQueries($id,$q);
}
?>