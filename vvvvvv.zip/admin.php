<html>
<head>
<head><title>VMTW ChatBot - Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="mdl/material.min.css">
<script src="mdl/material.min.js"></script>
<style>
div.mdl-layout__drawer{
  background:#999;
  border:none;
}
span.mdl-layout-title{
	font-size:2em;
font-family: 'David Libre', serif;
}
.side_title{
	color:#ffffff;
}
.mdl-layout__drawer .mdl-navigation .mdl-navigation__link {
	text-decoration:none;
font-family: 'David Libre', serif;
font-size:1.2em;
color:#ffffff;
}
.mdl-layout__drawer .mdl-navigation .mdl-navigation__link:hover{
	color:#000000;
	background:rgba(255,255,255,0.4);
	text-shadow: 1px 5px 15px black;
}
.demo-card-wide.mdl-card {
  width: 512px;
}
.demo-card-wide > .mdl-card__title {
  color: #fff;
  height: 176px;
  background: url('images/h.jpg') center / cover;
}
.demo-card-wide > .mdl-card__menu {
  color: #fff;
}
.mdl-layout__header{
	background-color: #229966;
}
.mdl-layout__drawer-button i{
	padding-top:10px;
}
#top1{
	width:100%;
	padding:15px;
}
.demo-card-wide{
	margin:auto;
}
.demo-card-square.mdl-card {
  width: 320px;
  height: 320px;
  float:left;
  margin:20px;
}
#people.demo-card-square > .mdl-card__title {
  color: #fff;
  background:
    url('images/p.jpeg') center / cover #46B6AC;
}
#words.demo-card-square > .mdl-card__title {
  color: #fff;
  background:
    url('images/w.jpg') center / cover #46B6AC;
}
#queries.demo-card-square > .mdl-card__title {
  color: #fff;
  background:
    url('images/q.jpg') center / cover #46B6AC;
}
	div.page-content{
		overflow:auto;
	}
</style>
</head>
<body>
<!-- The drawer is always open in large screens. The header is always shown,
  even in small screens. -->
  <?php
  
  
include "connection.php";
include "bot.php";
$bot = new Bot;
$np=$bot->numNewPeople();
$nq=$bot->numNewQueries();
$nw=$bot->numNewWords();
$total=$np+$nq+$nw;  
  ?>
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-drawer
            mdl-layout--fixed-header">
  <header class="mdl-layout__header">
    <div class="mdl-layout__header-row">
      <div class="mdl-layout-spacer"></div>
      <div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable
                  mdl-textfield--floating-label mdl-textfield--align-right">
        <label class="mdl-button mdl-js-button mdl-button--icon"
               for="fixed-header-drawer-exp">
          <i class="material-icons">search</i>
        </label>
        <div class="mdl-textfield__expandable-holder">
          <input class="mdl-textfield__input" type="text" name="sample"
                 id="fixed-header-drawer-exp">
        </div>
      </div>
    </div>
  </header>
  <div class="mdl-layout__drawer">
    <span class="mdl-layout-title">VMTW</span>
    <nav class="mdl-navigation">
      <a class="mdl-navigation__link" href="people.php">People</a>
      <a class="mdl-navigation__link" href="words.php">Words</a>
      <a class="mdl-navigation__link" href="queries.php">Unanswered</a> 
      <a class="mdl-navigation__link" href="queries_data.php">All queries</a> 
    </nav>
  </div>
  <main class="mdl-layout__content">
    <div class="page-content">
<div id="top1">	
<div class="demo-card-wide mdl-card mdl-shadow--2dp">
  <div class="mdl-card__title">
    <h2 class="mdl-card__title-text">Hello Admin</h2>
  </div>
  <div class="mdl-card__supporting-text">
    You have <?php echo $total; ?> new notifications
  </div>
  <div class="mdl-card__actions mdl-card--border">
    <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect" href="index.php">
      Open Assistant
    </a>
  </div>
</div>
	</div>
	<div id="people" class="demo-card-square mdl-card mdl-shadow--2dp">
  <div class="mdl-card__title mdl-card--expand">
    <h2 class="mdl-card__title-text">People</h2>
  </div>
  <div class="mdl-card__supporting-text">
    <?php echo $np; ?> new
  </div>
  <div class="mdl-card__actions mdl-card--border">
    <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect" href="people.php">
      Open
    </a>
  </div>
</div><div id="words" class="demo-card-square mdl-card mdl-shadow--2dp">
  <div class="mdl-card__title mdl-card--expand">
    <h2 class="mdl-card__title-text">Words</h2>
  </div>
  <div class="mdl-card__supporting-text">
    <?php echo $nw; ?> new
  </div>
  <div class="mdl-card__actions mdl-card--border">
    <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect" href="words.php">
      Open
    </a>
  </div>
</div><div id="queries" class="demo-card-square mdl-card mdl-shadow--2dp">
  <div class="mdl-card__title mdl-card--expand">
    <h2 class="mdl-card__title-text">Queries</h2>
  </div>
  <div class="mdl-card__supporting-text">
   <?php echo $nq; ?> new
  </div>
  <div class="mdl-card__actions mdl-card--border">
    <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect" href="queries.php">
      Open
    </a>
  </div>
</div>
	</div>
  </main>
</div>
</body>
</html>