<html>
<head><title>VMTW ChatBot</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="styles.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" >
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" ></script>
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<script type="text/javascript" src="js/jquery-3.2.1.js"></script>
<link rel="stylesheet" href="mdl/material.min.css">
<script src="mdl/material.min.js"></script>
<script>

$(document).ready(function(){
	
	var vol=0;
$("#on").hide();
$("#onoff").click(function(){
vol=(vol+1)%2;
if(vol==0){
$("#on").hide();
$("#off").show();
}
else{
$("#off").hide();
$("#on").show();
}
});
	
	
$("#msg").keyup(function(){
	var msg=$('#msg').val();
	if(msg.length < 1)
			$('#send').css('background-color','#d1d1d1');
	else
			$('#send').css('background-color','var(--theme-color)');
		
	});
	$('#msg').keypress(function (e) {
    if (e.which == '13') {
        $('#send').click();
    }
});
	
	
	
	function ring(data){
  $.post("ttscheck.php",
    {
        data:data
    },
    function(data){
	    var audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        var source = audioCtx.createBufferSource();
        var xhr = new XMLHttpRequest();
        xhr.open('GET', data);
        xhr.responseType = 'arraybuffer';
        xhr.addEventListener('load', function (r) {
            audioCtx.decodeAudioData(
                    xhr.response, 
                    function (buffer) {
                        source.buffer = buffer;
                        source.connect(audioCtx.destination);
                        source.loop = false;
                    });
            source.start(0);
        });
        xhr.send();
    });
}

	
	
	
	
	$('#send').click(function(){
	var msg=$('#msg').val();
	if(msg.length > 0 ){
	$('#msg').val("");
				$('#box').append('<div class="human"><div id=chatname><b>You</b></div><div id=chatmsg>'+msg+'</div></div>');
				$('#box').scrollTop($("#box")[0].scrollHeight);
			$('#send').css('background-color','#d1d1d1');
		    $.ajax({
				type: 'POST' ,
			url: 'action.php',
			async:false,
			data : {
				query : msg 
			},
			success: function(data){
				$('#box').append(data);
				$('#box').scrollTop($("#box")[0].scrollHeight);
				if(vol==1){
					ring($(".bot:last #chatmsg").html());
				}
			}
			});
		}
	});
	
	
	
	
	
	});
</script>
</head>
<body height=600 width=200>
<div id="main">
<div id="head" class="container">
<div id="name">VMTW ChatBot 	<button id="onoff" class="mdl-button mdl-js-button mdl-button--icon" style="position:absolute; right:10; color:#fff;
">
  <i class="material-icons" id="on" >volume_up</i>
  <i class="material-icons" id="off" >volume_off</i>
</button>
	</div>

</div>
<div id="box" class="container">

</div>
<div id="foot" class="container">
  <input type="text" name="msg" id="msg" placeholder="Type your message" >
  
    <button id="send"
        class="mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect">
  <i class="material-icons">send</i>
</button>
</div>
</div>
</body>
</html;>