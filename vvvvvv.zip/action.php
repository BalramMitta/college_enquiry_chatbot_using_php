<?php

if(isset($_POST["query"])){
	$botname="Bot";
	
	
	
$query=strtolower($_POST["query"]);
$split_query=explode(" ",$query);

include "connection.php";
include("common.php");
include("user.php");
	$u=new User;

$cmn=new Common; 
$temp_arr=$cmn->changeSimilar($split_query);
$new_split_query=$temp_arr[0];
	
$replaced_query = $cmn->getString($new_split_query);
$new_query=$cmn->modifyString($new_split_query);
$response_check=$cmn->getResponse($new_query,$temp_arr[1]);
if($response_check!='0'){
	$reply=$response_check;
}
else{
$response_check=$cmn->advanceSearch($new_query);
if($response_check!='0'){
	$reply=$response_check;
}
else{
	$reply="Sorry!we can't understand";
	$u->addQueries($query," ");
	}
	foreach($temp_arr[1] as $w){
		$u->addWords($w);
	}
}

	
		echo '<div class="bot"><div id=chatname ><b>'.$botname.'</b></div><div id=chatmsg >'.$reply.'</div></div>'; 
}
?>

