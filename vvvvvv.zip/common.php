<?php 

class Common{
	function getString($qstr){
$new_str="";
foreach($qstr as $w){
$new_str=$new_str." ".$w;
}
return trim($new_str);
}
	

function getResponse($t_query,$arr){
global $conn;
	$sql="select * from responses where id in (select id from queries where query='$t_query')";
$result=$conn->query($sql);
if($result->num_rows>0){
$row=$result->fetch_assoc();
if($row["action"]=="display")
return $row["response"];
else{
	$strq=implode(" ",$arr);
	$sql="select * from people where name='$strq'";
	$res=$conn->query($sql);
	if($res->num_rows>0){
		$row=$res->fetch_assoc();
		return $row["desc"];
	}
	else{
		if($t_query!='*'){
		return "Sorry, We cannot find him/her.";
		}
		else{
		return 0;
		}
	}
}
}else{
return 0;
}
}
	
function changeSimilar($arr){
$n=sizeof($arr);
global $conn;
$unknowns=array();
for($i=0;$i<$n;$i++){
$sql="select * from similar_words where similar='$arr[$i]'";
$result=$conn->query($sql);
if($result->num_rows>0){
$row=$result->fetch_assoc();
$arr[$i]=$row["word"];
}
else{
$unknowns[]=$arr[$i];	
}
}
return array($arr,$unknowns);
}
function modifyString($qstr){
$new_str="";
global $conn;
foreach($qstr as $w){
$sql="select * from dictionary where word='$w'";
$result=$conn->query($sql);
if($result->num_rows>0){
$new_str=$new_str." ".$w;
}
else{
$new_str=$new_str." *";
}
}
while(strpos($new_str,"* *")){
$new_str=str_replace("* *","*",$new_str);
}
return trim($new_str);

}

function advanceSearch($b){
	
global $conn;

	
	
$sql="select * from queries";
$res=$conn->query($sql);
$row=$res->fetch_assoc();
similar_text($b,$row['query'],$max_match);
		$max_id=$row["id"];
		$max_q=$row["query"];
while($row=$res->fetch_assoc()){
	
	
similar_text($b,$row['query'],$match);
	
	if($match>$max_match){
		$max_match=$match;
		$max_id=$row["id"];
		$max_q=$row["query"];
	}
}
	
if($max_match > 75){
	$sql1="select * from responses where id='$max_id'";
	$res1=$conn->query($sql1);
	$row1=$res1->fetch_assoc();
	if($row1["action"]=="display")
      $response=$row1["response"];
else{
         return 0;
}
	return '<p><b><em>Did you mean:</em></b><em>'.$max_q.'?</em></p><p>'.$response.'</p>';
}
	else 
	return 0;
	
}

}




?>
