<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="mdl/material.min.css">
<script type="text/javascript" src="js/jquery-3.2.1.js"></script>
<script src="mdl/material.min.js"></script>
<style>
.mdl-layout__header{
	background-color: #229966;
}
.mdl-layout__drawer-button i{
	padding-top:10px;
}
.demo-card-square{
	float:left;
}
	div.page-content{
		overflow:auto;
	}
#rem{
	position:relative;
	display:inline-block;
	float:left;
	margin:10px;
}
#add{
	position:relative;
	display:inline-block;
	float:right;
	margin:10px;
}
</style>
<script>

function remP(id){
	$("#"+id).hide();
	$.ajax({
		type:"POST",
		data:{
		id:id
		},
		url:"remP.php"
	});
	
}
function addP(id){
	var name=$("#"+id+" #name").val();
	var desc=$("#"+id+" #desc").val();
	if(name.length>0 && desc.length>0){
	$.ajax({
		type:"POST",
		data:{
		id:id,
		name:name,
		desc:desc
		},
		url:"addP.php",
		success:function(data){
			alert(data);
			if(id!="000")
			remP(id);
			else{
			location.reload();
			}
		}
	});
	}
}

$(document).ready(function(){

});
</script>
</head>
<body>
<!-- The drawer is always open in large screens. The header is always shown,
  even in small screens. -->
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-drawer
            mdl-layout--fixed-header">
  <header class="mdl-layout__header">
    <div class="mdl-layout__header-row">
      <div class="mdl-layout-spacer"></div>
      <div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable
                  mdl-textfield--floating-label mdl-textfield--align-right">
        <label class="mdl-button mdl-js-button mdl-button--icon"
               for="fixed-header-drawer-exp">
          <i class="material-icons">search</i>
        </label>
        <div class="mdl-textfield__expandable-holder">
          <input class="mdl-textfield__input" type="text" name="sample"
                 id="fixed-header-drawer-exp">
        </div>
      </div>
    </div>
  </header>
  <div class="mdl-layout__drawer">
    <span class="mdl-layout-title">VMTW</span>
    <nav class="mdl-navigation">
      <a class="mdl-navigation__link" href="people.php">People</a>
      <a class="mdl-navigation__link" href="words.php">Words</a>
      <a class="mdl-navigation__link" href="queries.php">Unanswered</a> 
      <a class="mdl-navigation__link" href="queries_data.php">All queries</a> 
    </nav>
  </div>
  <main class="mdl-layout__content">
    <div class="page-content">
		<?php 
	include "connection.php";
	$sql="select * from temp_people";
	$result=$conn->query($sql);
	if($result->num_rows>0){
		while($row=$result->fetch_assoc()){
			$tid=$row["id"];
			$name=$row["name"];
			$desc=$row["desc"];
	?>
	
	<div id="<?php echo $tid; ?>" class="demo-card-square mdl-card mdl-shadow--2dp mdl-cell mdl-cell--4-col">
  <div class="mdl-card__supporting-text">
      <div class="mdl-textfield mdl-js-textfield">
    <input class="mdl-textfield__input" type="text" pattern="[a-zA-Z]*$" name="name" value="<?php echo $name; ?>" id="name">
    <label class="mdl-textfield__label" for="name">Name</label>
    <span class="mdl-textfield__error">Enter only alphabets</span>
  </div>  <div class="mdl-textfield mdl-js-textfield">
    <input class="mdl-textfield__input" type="text" pattern="[a-zA-Z]*$" name="desc" value="<?php echo $desc; ?>" id="desc">
    <label class="mdl-textfield__label" for="desc">Description</label>
    <span class="mdl-textfield__error">Enter only alphabets</span>
  </div>
  </div>
  <div class="mdl-card__actions mdl-card--border">
 <button id= "rem" class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--accent" onclick=remP('<?php echo $tid; ?>')>
  Remove
</button>
<button  id="add" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent" onclick=addP('<?php echo $tid; ?>') >
  Add
</button>
  </div>
</div>

<?php
	}
	}
?>
	<div id="000" class="demo-card-square mdl-card mdl-shadow--2dp mdl-cell mdl-cell--4-col">
  <div class="mdl-card__supporting-text">
      <div class="mdl-textfield mdl-js-textfield">
    <input class="mdl-textfield__input" type="text" pattern="[a-zA-Z]*$" name="name" id="name">
    <label class="mdl-textfield__label" for="name">Name</label>
    <span class="mdl-textfield__error">Enter only alphabets</span>
  </div>  <div class="mdl-textfield mdl-js-textfield">
    <input class="mdl-textfield__input" type="text" name="desc" id="desc">
    <label class="mdl-textfield__label" for="desc">Description</label>
  </div>
  </div>
  <div class="mdl-card__actions mdl-card--border">
<button  id="add" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent" onclick=addP('000') >
  Add New Person
</button>
  </div>
</div>
	</div>
  </main>
</div>
</body>
</html>