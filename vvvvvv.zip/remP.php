<?php
if(isset($_POST["id"])){
include "connection.php";
$id=$_POST["id"];
$sql="delete from temp_people where id=$id";
$conn->query($sql);
}
?>