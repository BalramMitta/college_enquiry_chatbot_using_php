<?php
if(isset($_POST["id"])){
include "connection.php";
$id=$_POST["id"];
$name=$_POST["name"];
$desc=$_POST["desc"];
include "bot.php";
 $b=new Bot;
$b->addPeople($name,$desc);
}
?>